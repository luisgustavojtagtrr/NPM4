export default function MyTitle(props:any) {
    return (
      <>
        <div style={{textAlign:"center"}}>
            <h1>{props.title}</h1>
            <p>DOCENTE: AHORA SI LLOREN POR QUE SE VAN A LANZAR</p>
            <p>ESTUDIANTE: AQUE NO</p>
        </div>
      </>
    )
  }
  