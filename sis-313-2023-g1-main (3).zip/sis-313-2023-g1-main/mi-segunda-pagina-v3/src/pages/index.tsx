import Logo from './components/Logo'
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import {ItemGrid} from './components/ItemGrid'


export default function Home() {
  return (
    <>
      <div style={{height:"100vh"}}>
        <Box sx={{ flexGrow: 1 }}>
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <ItemGrid>
                  <Logo/>
              </ItemGrid>
            </Grid>
            <Grid item xs={6}>
              <ItemGrid>
                <h1>IMAGEN</h1>
              </ItemGrid>
            </Grid>
          </Grid>
        </Box>
      </div>
    </>
  )
}
